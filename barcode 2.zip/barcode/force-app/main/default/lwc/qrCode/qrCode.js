import { LightningElement, track, api } from 'lwc';
import getPackage from '@salesforce/apex/getPackageController.getPackage';
// import jsPDF from '@salesforce/resourceUrl/jspdf';
import pdflib from "@salesforce/resourceUrl/pdflib";
import { loadScript } from 'lightning/platformResourceLoader';




export default class QrCode extends LightningElement {
    @api recordId;
    @track barcodeValue = '';
    @track qrValue = '';
    preValue = '';
    @track wrapperClass = '';
    handleClick(event) {
        console.log("clicked");

        let qrInput = this.template.querySelector('lightning-input');
        let qrImg = this.template.querySelector('img');
        let generateBtn = this.template.querySelector('.generate-btn');

        this.qrValue = qrInput.value.trim();
        if (!this.qrValue || this.preValue === this.qrValue) {
            return;
        }
        this.preValue = this.qrValue;

        generateBtn.label = "Generating QR Code...";
        qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${this.qrValue}`;

        qrImg.addEventListener("load", () => {
            this.wrapperClass = "active";
            generateBtn.label = "Generate QR Code";
        });
    }

    @track isModalOpen = false;
    @track selected = [];
    @track selectedValues = [];
    options = [
        { label: 'Package Name', value: 'Package Name' },
        { label: 'Email', value: 'Email' },
        { label: 'Date', value: 'Date' },
        { label: 'Status', value: 'Status' },
        { label: 'Tenant', value: 'Tenant' },
        { label: 'Package Size', value: 'Package Size' },
        { label: 'Tracking Number', value: 'Tracking Number' },
    ];

    openModal() {
        this.selected = this.selectedValues;
        this.isModalOpen = true;
    }

    closeModal() {
        this.isModalOpen = false;
    }

    handleChange(event) {
        this.selected = event.detail.value;
    }

    handleSave() {
        console.log('Selected values: ', this.selectedValues)
        // Perform actions to save the selected values here
        this.selectedValues = this.selected;

        // Close the modal
        this.isModalOpen = false;

        // Check if the selected values include any of the predefined options
        let matchFound = false;
        for (const element of this.selectedValues) {
            for (const option of this.options) {
                if (element === option.value) {
                    console.log(`Array contains "${option.value}": true`);
                    matchFound = true;
                    break;
                }
            }
            if (matchFound) {
                break;
            }
        }

        if (!matchFound) {
            console.log('No matching fields found!');
        }

        //code 

        // Check if the selectedValues array contains 'Package Name'
        if (this.selectedValues.includes('Package Name')) {
            // Do something
            console.log('Package Name is selected!');
        }

        // Check if the selectedValues array contains 'Tenant'
        if (this.selectedValues.includes('Tenant')) {
            // Do something
            console.log('Tenant is selected!');
        }

        // Check if the selectedValues array contains 'Status'
        if (this.selectedValues.includes('Status')) {
            // Do something
            console.log('Status is selected!');
        }

        // Check if the selectedValues array contains 'Date'
        if (this.selectedValues.includes('Date')) {
            // Do something
            console.log('Date is selected!');
        }

        // Check if the selectedValues array contains 'Email'
    }
    handleSave() {
        console.log('Selected values: ', this.selectedValues)
    
        // Perform actions to save the selected values here
        this.selectedValues = this.selected;
    
        // Close the modal
        this.isModalOpen = false;
    
        let matchFound = false;
    
        // Check if the selectedValues array contains any of the predefined options
        for (const element of this.selectedValues) {
            for (const option of this.options) {
                if (element === option.value) {
                    console.log(`Array contains "${option.value}": true`);
                    matchFound = true;
                    break;
                }
            }
            if (matchFound) {
                break;
            }
        }
    
        if (!matchFound) {
            console.log('No matching fields found!');
        } else {
            // Call the Apex method to get the package information
            getPackage({ recordId: this.recordId })
                .then((result) => {
                    let item = result[0];
                    let objTemp = {};
    
                    // Create an object with the package information based on the selected values
                    if (this.selectedValues.includes('Package Name')) {
                        objTemp['Package Name'] = item.Name;
                    }
                    if (this.selectedValues.includes('Tenant')) {
                        objTemp['Tenant'] = item.Tenant__c;
                    }
                    if (this.selectedValues.includes('Status')) {
                        objTemp['Status'] = item.Status__c;
                    }
                    if (this.selectedValues.includes('Date')) {
                        objTemp['Date'] = item.Date__c;
                    }
                    if (this.selectedValues.includes('Email')) {
                        objTemp['Email'] = item.Email__c;
                    }
                    if (this.selectedValues.includes('Tracking Number')) {
                        objTemp['Tracking Number'] = item.Tracking_Number__c;
                    }
                    if (this.selectedValues.includes('Package Size')) {
                        objTemp['Package Size'] = item.Package_Size__c;
                    }
    
                    // Create a JSON string with the object
                    let jsonString = JSON.stringify(objTemp);
    
                    // Set the input value to the JSON string
                    let qrInput = this.template.querySelector('lightning-input');
                    qrInput.value = jsonString;
                })
                .catch((error) => {
                    console.error(error);
                });
        }
    }
    

 
// PF section 
renderedCallback() {
    loadScript(this, pdflib).then(() => {});
  }
  async createPdf() {
    const pdfDoc = await PDFLib.PDFDocument.create();
    const timesRomanFont = await pdfDoc.embedFont(
      PDFLib.StandardFonts.TimesRoman
    );

    const page = pdfDoc.addPage();
    const { width, height } = page.getSize();
    const fontSize = 30;
    page.drawText(`QR Code Value: ${this.selectedValues}` , {
      x: 50,
      y: height - 4 * fontSize,
      size: fontSize,
      font: timesRomanFont,
      color: PDFLib.rgb(0, 0.53, 0.71)
    });

    const pdfBytes = await pdfDoc.save();
    this.saveByteArray("My PDF", pdfBytes);
  }
  saveByteArray(pdfName, byte) {
    var blob = new Blob([byte], { type: "application/pdf" });
    var link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    var fileName = pdfName;
    link.download = fileName;
    link.click();
  }



}        
// css , html , sass, js , node.js. react,js. less . apex , tree,js, 