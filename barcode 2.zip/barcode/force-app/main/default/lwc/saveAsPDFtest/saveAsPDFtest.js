import { LightningElement } from 'lwc';
import pdflib from "@salesforce/resourceUrl/pdflib";
import { loadScript } from "lightning/platformResourceLoader";

export default class SaveAsPDFtest extends LightningElement {
  qrImg = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=';
  selectedValues = 'Sample QR Code Data';

  renderedCallback() {
    loadScript(this, pdflib).then(() => {});
  }

  async createPdf() {
    const pdfDoc = await PDFLib.PDFDocument.create();
    const timesRomanFont = await pdfDoc.embedFont(
      PDFLib.StandardFonts.TimesRoman
    );

    const page = pdfDoc.addPage();
    const { width, height } = page.getSize();
    const fontSize = 30;

    // Add QR code value field
    page.drawText(`QR Code Value: ${this.selectedValues}`, {
      x: 50,
      y: height - 4 * fontSize,
      size: fontSize,
      font: timesRomanFont,
      color: PDFLib.rgb(0, 0.53, 0.71)
    });

    // Add QR code image field
    const qrImageBytes = await fetch(`${this.qrImg}${this.selectedValues}`)
      .then(res => res.arrayBuffer());

    const qrImage = await pdfDoc.embedPng(qrImageBytes);
    const qrImageDims = qrImage.scale(0.5);
    page.drawImage(qrImage, {
      x: page.getWidth() / 2 - qrImageDims.width / 2,
      y: height - 250,
      width: qrImageDims.width,
      height: qrImageDims.height,
    });

    const pdfBytes = await pdfDoc.save();
    this.saveByteArray("My PDF", pdfBytes);
  }

  saveByteArray(pdfName, byte) {
    const blob = new Blob([byte], { type: "application/pdf" });
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    const fileName = pdfName;
    link.download = fileName;
    link.click();
  }
}
