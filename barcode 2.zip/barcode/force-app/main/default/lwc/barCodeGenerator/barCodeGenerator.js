import { LightningElement, api, wire } from 'lwc';
import getPackage from '@salesforce/apex/getPackageControllerBarCode.getPackage';
import { loadScript } from 'lightning/platformResourceLoader';
import Barcode from '@salesforce/resourceUrl/BarCode';

const BARCODE_TYPES = [
    { label: 'CODE39', value: 'CODE39' },
    { label: 'CODE128', value: 'CODE128' },
    { label: 'CODE128A', value: 'CODE128A' },
    { label: 'CODE128B', value: 'CODE128B' },
];

export default class BarCodeGenerator extends LightningElement {
    @api recordId;
    packageData;
    barcodeValue = '';
    barcodeOptions = BARCODE_TYPES;
    selectedBarcodeOption = BARCODE_TYPES[0].value;

    connectedCallback() {
        this.getPackageController(this.recordId)
        Promise.all([
            loadScript(this, Barcode)
        ]).then(() => {
            this.renderButtons();
        }).catch(error => {
            window.console.log("Error " + error.body.message);
        });
    }

    renderButtons() {
        this.boolShowSpinner = false;
    }

    handleValueChange(event) {
        this.barcodeValue = event.target.value;
    }

    handleBarcodeTypeChange(event) {
        this.selectedBarcodeOption = event.target.value;
    }

    clearBarcode() {
        const canvas = this.template.querySelector('[data-id="barcode"]');
        const context = canvas.getContext('2d');
        context.clearRect(0, 0, canvas.width, canvas.height);
        canvas.width = canvas.width;
    }

    generateBarcode() {
        this.clearBarcode();
        const canvas = this.template.querySelector('[data-id="barcode"]');
        JsBarcode(canvas, this.barcodeValue, {
            format: this.selectedBarcodeOption
        });
    }

    // @wire(getPackage, { recordId: '$recordId' })
    // wiredPackageData({ error, data }) {
    //     if (data) {
    //         console.log(data)
    //         this.packageData = data[0];
    //         console.log(this.packageData.Id); // example of accessing package data
    //     } else if (error) {
    //         console.error(error);
    //     }
    // }

    getPackageController(recId){
        getPackage({recordId: recId})
        .then((result) => {
            let item = result[0]
            let objTemp = {
                // Id: item.Id,
                // 1: item.Name,
                // 1: item.Tenant__c,
                1: item.Status__c,
                // 4: item.Date__c
                }  
                 this.barcodeValue = JSON.stringify(objTemp)         
        })
        .catch((error) => {
            console.log(error)
        })
    }
    
}
